
import numpy as np

def refine_data(data, balance_factor, entropy_weight, info_weight, iterations=10):
    refined = data.copy()
    for _ in range(iterations):
        state_1_density = np.mean(refined) * entropy_weight
        state_2_density = np.mean(refined) * info_weight
        ratio = state_2_density / (state_1_density + 1e-9)
        adjustment = balance_factor * (np.mean(refined) - refined) * ratio
        refined += adjustment
    return refined
