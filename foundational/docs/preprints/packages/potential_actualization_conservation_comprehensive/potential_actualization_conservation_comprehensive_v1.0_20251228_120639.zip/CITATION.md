# Citation

## BibTeX

```bibtex
@misc{dawnfield2025potentialactualizat,
    title = {Potential Actualization Conservation Comprehensive},
    author = {Dawn Field Institute Research Team},
    year = {2025},
    publisher = {Zenodo},
    doi = {10.5281/zenodo.XXXXXXX},
    url = {https://doi.org/10.5281/zenodo.XXXXXXX}
}
```

## Plain Text

Dawn Field Institute Research Team. (2025). Potential Actualization Conservation Comprehensive. Zenodo. https://doi.org/10.5281/zenodo.XXXXXXX

---

*Update DOI after Zenodo upload.*
